Mirror VR samples can be found here:
https://github.com/MirrorNetworking/ExamplesVR

The VR samples need a few extra dependencies,
so they aren't stored in the main Mirror repository here.
