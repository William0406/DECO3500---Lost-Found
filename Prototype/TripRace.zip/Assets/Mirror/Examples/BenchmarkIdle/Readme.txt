This is used for CCU tests.
White = players, Red = monsters.

In NetworkManager:
- set the server's IP/Port
- enable 'auto start headless server', build server binary.
- enable 'auto connect headless client', build client binary.

Launch 1 server with N clients.