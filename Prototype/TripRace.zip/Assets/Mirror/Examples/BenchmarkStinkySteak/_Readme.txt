Steak's Netcode Benchmark from:
https://github.com/StinkySteak/unity-netcode-benchmark/

Results:
https://colorful-flyaway-e2f.notion.site/Netcode-Benchmark-f431976feb014ce48e030786f116e403?pvs=4

=> Copied into Mirror Examples so we can iterate on bandwidth improvements more quickly.
=> Also copied a few dependencies from:
   https://github.com/StinkySteak/unity-netcode-benchmark/blob/master/mirror/Packages/manifest.json
=> replaced TextMeshPro with TextMesh