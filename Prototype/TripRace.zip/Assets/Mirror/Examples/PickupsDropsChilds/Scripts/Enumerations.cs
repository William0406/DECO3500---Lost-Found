﻿namespace Mirror.Examples.PickupsDropsChilds
{
    public enum EquippedItem : byte
    {
        nothing,
        ball,
        bat,
        box
    }
}
